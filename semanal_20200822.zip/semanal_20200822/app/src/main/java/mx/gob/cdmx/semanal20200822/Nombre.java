package mx.gob.cdmx.semanal20200822;

public class Nombre  {

    public static final String customURL = "https://opinion.cdmx.gob.mx/encuestas/";
    public static final String encuesta = "semanal_20200822";
    public static final String USUARIO = "usuario";
    public static final String PADRON = "padron";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String IMEI = "imei";

    public String nombreEncuesta(){

        final String nombreEncuesta = "semanal_20200822";
        return nombreEncuesta;
    }

    public String nombreDatos(){

        final String nombreEncuesta = "datos_semanal_20200822";
        return nombreEncuesta;
    }

}	 
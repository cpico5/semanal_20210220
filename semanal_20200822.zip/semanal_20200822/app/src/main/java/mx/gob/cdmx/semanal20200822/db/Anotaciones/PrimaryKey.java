package mx.gob.cdmx.semanal20200822.db.Anotaciones;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by KC on 5/11/2016.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface PrimaryKey {
}